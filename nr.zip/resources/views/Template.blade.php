	@extends('layouts.page')
	
	@section('page-title')
	@endsection
	
	@section('page-content')
	@endsection
	
	@section('header-custom')
	@endsection
	
	@section('footer-custom')
	@endsection
	