@php
	print_r($data);
@endphp
<div class="form-group">
    <select class="choices form-select multiple-remove" multiple="multiple">
        <optgroup label="Siswa">
			
			
			
        </optgroup>
    </select>
</div>
