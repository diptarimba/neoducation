<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Leveltentors extends Model
{
    //
}
